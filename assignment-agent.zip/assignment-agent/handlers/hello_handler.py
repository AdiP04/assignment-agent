def hello_handler(message: str):
    print(f"Hello Handler: Received message '{message}'")