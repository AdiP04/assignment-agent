import time

def balance_checker(agent):
    while True:
        print(f"Checking balance for {agent.wallet_address}: 100 MOCK tokens")
        time.sleep(10)